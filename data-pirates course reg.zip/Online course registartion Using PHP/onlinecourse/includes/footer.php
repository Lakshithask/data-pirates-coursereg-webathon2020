<footer>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    &copy; <?php echo date('Y');?> C A P | By : <a href="" target="_blank">DATA PIRATES</a>
                </div>

            </div>
        </div>
    </footer>
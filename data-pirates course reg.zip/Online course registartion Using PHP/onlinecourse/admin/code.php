<?php
session_start();
$con=mysqli_connect('localhost','root','','adminp');

require 'vendor/autoload.php';
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

if(isset($_POST['save_excel_data']))
{
    $fileName=$_FILES['import_file']['name'];
    $file_ext= pathinfo($fileName, PATHINFO_EXTENSION);
    $allowed_ext=['xls','csv','xlsx'];
    if(in_array($file_ext,$allowed_ext)){
        $inputFileNamePath =$_FILES['import_file']['tmp_name'];
        /** Load $inputFileName to a Spreadsheet object **/
        $spreadsheet = \PhpOffice\PhpSpreadsheet\IOFactory::load($inputFileNamePath);
        $data=$spreadsheet->getActiveSheet()->toArray();

        foreach($data as $row){
            $coursecode=$row['0'];
            $cname=$row['1'];
            $lhours=$row['2'];
            $thours=$row['3'];
            $phours=$row['4'];

            $courseQuery="INSERT INTO course (coursecode,cname,lhours,thours,phours) VALUES('$coursecode','$cname','$lhours','$thours','$phours')";
            $result=mysqli_query($con,$courseQuery);
            $msg=true;
        }
        if(isset($msg)){
        $_SESSION['message']="Successfully imported";
        header('Location: department.php');
        exit(0);
        }
        else{
        $_SESSION['message']="Successfully imported";
        header('Location: department.php');
        exit(0);
    }
}
else{
    $_SESSION['message']="Invalid File";
    header('Location: department.php');
    exit(0);
}
}

?>
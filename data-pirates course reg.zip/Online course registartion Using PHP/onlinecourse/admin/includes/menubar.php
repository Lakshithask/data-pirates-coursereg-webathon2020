<section class="menu-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="navbar-collapse collapse ">
                        <ul id="menu-top" class="nav navbar-nav navbar-right">

                            <li><a   href="department.php">Upload Courses</a></li>
                             <li><a href="course.php">View and Add Courses</a></li>
                              <li><a href="student-registration.php">Wishlist Data</a></li>
                               <li><a href="manage-students.php">Faculty Info</a></li>
                               <li><a href="enroll-history.php">Faculty Preference</a></li>
                               <li><a href="user-log.php">Allocation </a></li>
                                
                            <li><a href="logout.php">Logout</a></li>

                        </ul>
                    </div>
                </div>

            </div>
        </div>
    </section>